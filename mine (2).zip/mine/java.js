// BOUTON LEFT

document.addEventListener('DOMContentLoaded', function() {
    // Sélectionne tous les éléments avec la classe 'bouton-class'
    const buttons = document.querySelectorAll('.bouton-class');

    buttons.forEach(function(button) {
        button.style.position = 'relative';
        button.style.overflow = 'hidden';

        // Création du pseudo-élément via JS n'est pas directement possible,
        // donc nous allons utiliser une autre approche.

        button.addEventListener('mouseenter', function() {
            // Vérifie si l'effet est déjà appliqué pour éviter les doublons
            if (!button.querySelector('.underline-effect')) {
                const underline = document.createElement('span');
                underline.classList.add('underline-effect');
                underline.style.position = 'absolute';
                underline.style.bottom = '0';
                underline.style.left = '0';
                underline.style.width = '100%';
                underline.style.height = '2px';
                underline.style.backgroundColor = 'white';
                underline.style.transform = 'scaleX(0)';
                underline.style.transition = 'transform 0.3s ease';

                // Ajoute l'élément span comme enfant du bouton
                button.appendChild(underline);
            }

            // Anime l'effet
            requestAnimationFrame(function() {
                button.querySelector('.underline-effect').style.transform = 'scaleX(1)';
            });
        });

        button.addEventListener('mouseleave', function() {
            // Retire l'animation
            if (button.querySelector('.underline-effect')) {
                button.querySelector('.underline-effect').style.transform = 'scaleX(0)';
            }
        });
    });
});

// BOUTON RIGHT 

document.addEventListener('DOMContentLoaded', function() {
    // Sélectionne tous les éléments avec la classe 'bouton-class'
    const buttons = document.querySelectorAll('.bouton-fill');

    buttons.forEach(function(button) {
        button.style.position = 'relative';
        button.style.overflow = 'hidden';

        // Création du pseudo-élément via JS n'est pas directement possible,
        // donc nous allons utiliser une autre approche.

        button.addEventListener('mouseenter', function() {
            // Vérifie si l'effet est déjà appliqué pour éviter les doublons
            if (!button.querySelector('.underline-effect')) {
                const underline = document.createElement('span');
                underline.classList.add('underline-effect');
                underline.style.position = 'absolute';
                underline.style.bottom = '0';
                underline.style.left = '0';
                underline.style.width = '100%';
                underline.style.height = '2px';
                underline.style.backgroundColor = 'black';
                underline.style.transform = 'scaleX(0)';
                underline.style.transition = 'transform 0.3s ease';

                // Ajoute l'élément span comme enfant du bouton
                button.appendChild(underline);
            }

            // Anime l'effet
            requestAnimationFrame(function() {
                button.querySelector('.underline-effect').style.transform = 'scaleX(1)';
            });
        });

        button.addEventListener('mouseleave', function() {
            // Retire l'animation
            if (button.querySelector('.underline-effect')) {
                button.querySelector('.underline-effect').style.transform = 'scaleX(0)';
            }
        });
    });
});

// BOUTON ACCUILLE

document.addEventListener('DOMContentLoaded', function() {
    // Sélectionne tous les éléments avec la classe 'bouton-class'
    const buttons = document.querySelectorAll('.welcomes-right');

    buttons.forEach(function(button) {
        button.style.position = 'relative';
        button.style.overflow = 'hidden';

        // Création du pseudo-élément via JS n'est pas directement possible,
        // donc nous allons utiliser une autre approche.

        button.addEventListener('mouseenter', function() {
            // Vérifie si l'effet est déjà appliqué pour éviter les doublons
            if (!button.querySelector('.underline-effect')) {
                const underline = document.createElement('span');
                underline.classList.add('underline-effect');
                underline.style.position = 'absolute';
                underline.style.bottom = '0';
                underline.style.left = '0';
                underline.style.width = '100%';
                underline.style.height = '2px';
                underline.style.backgroundColor = 'black';
                underline.style.transform = 'scaleX(0)';
                underline.style.transition = 'transform 0.3s ease';

                // Ajoute l'élément span comme enfant du bouton
                button.appendChild(underline);
            }

            // Anime l'effet
            requestAnimationFrame(function() {
                button.querySelector('.underline-effect').style.transform = 'scaleX(1)';
            });
        });

        button.addEventListener('mouseleave', function() {
            // Retire l'animation
            if (button.querySelector('.underline-effect')) {
                button.querySelector('.underline-effect').style.transform = 'scaleX(0)';
            }
        });
    });
});

// ANIMATION TEXTE DISCORD // 

document.addEventListener('DOMContentLoaded', function() {
    const discordButton = document.querySelector('.boutondiscord');
    
    function restartAnimation() {
        discordButton.classList.remove('typing-animation');
        void discordButton.offsetWidth; // Trigger un reflow pour relancer l'animation
        discordButton.classList.add('typing-animation');
    }

    // Relancer l'animation toutes les 2.5 secondes (ajustez selon vos besoins)
    setInterval(restartAnimation, 2500);
});

// SLIDER // 

document.addEventListener('DOMContentLoaded', function() {
    const sliderContainer = document.querySelector('.slider');
    const slideContainer = document.querySelector('.sliderpartenair'); // Correction du sélecteur
    const slides = document.querySelectorAll('.imgslide');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');

    let currentIndex = 0;

    function updateSlide() {
        slideContainer.style.transform = `translateX(${-currentIndex * 100}%)`;
    }

    function nextSlide() {
        currentIndex = (currentIndex + 1) % slides.length;
        updateSlide();
    }

    function prevSlide() {
        currentIndex = (currentIndex - 1 + slides.length) % slides.length;
        updateSlide();
    }

    function updateSlide() {
        const slideWidth = sliderContainer.offsetWidth; // Utilisez la largeur du conteneur du slider
        slideContainer.style.transform = `translateX(${-currentIndex * slideWidth}px)`;
    }
    

    prevBtn.addEventListener('click', prevSlide);
    nextBtn.addEventListener('click', nextSlide);

    // Correction du commentaire pour correspondre à l'intervalle réel
    setInterval(nextSlide, 3000); // Auto-advance every 3 seconds
});

// SLIDER MISE EN AVANT //

document.addEventListener('DOMContentLoaded', function() {
    const sliderContainer = document.querySelector('.slidermise');
    const slideContainer = document.querySelector('.slidermiseavant');
    const slides = document.querySelectorAll('.imgmise');
    const prevBtn = document.querySelector('.prev-btn'); // Assurez-vous que votre HTML a un élément avec cette classe
    const nextBtn = document.querySelector('.next-btn'); // Assurez-vous que votre HTML a un élément avec cette classe

    let currentIndex = 0;

    function updateSlide() {
        const slideWidth = sliderContainer.offsetWidth; // Utilisez la largeur du conteneur du slider
        slideContainer.style.transform = `translateX(${-currentIndex * slideWidth}px)`;
    }

    function nextSlide() {
        currentIndex = (currentIndex + 1) % slides.length;
        updateSlide();
    }

    function prevSlide() {
        currentIndex = (currentIndex - 1 + slides.length) % slides.length;
        updateSlide();
    }

    prevBtn.addEventListener('click', prevSlide);
    nextBtn.addEventListener('click', nextSlide);

    setInterval(nextSlide, 600); // Auto-advance every 5 seconds
});

