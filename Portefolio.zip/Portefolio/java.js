document.addEventListener('DOMContentLoaded', function() {
    // Sélectionne tous les éléments avec la classe 'bouton'
    const boutons = document.querySelectorAll('.bouton');

    boutons.forEach(function(bouton) {
        // Ajustement: pas besoin de définir position et overflow ici

        bouton.addEventListener('mouseenter', function() {
            // Vérifie si l'effet est déjà appliqué pour éviter les doublons
            if (!bouton.querySelector('.underline-effect')) {
                const underline = document.createElement('span');
                underline.classList.add('underline-effect');
                underline.style.position = 'absolute';
                underline.style.bottom = '0';
                underline.style.left = '0';
                underline.style.width = '100%';
                underline.style.height = '2px';
                underline.style.backgroundColor = 'white';
                underline.style.transform = 'scaleX(0)';
                underline.style.transition = 'transform 0.3s ease';

                bouton.appendChild(underline);
            }

            requestAnimationFrame(function() {
                bouton.querySelector('.underline-effect').style.transform = 'scaleX(1)';
            });
        });

        bouton.addEventListener('mouseleave', function() {
            if (bouton.querySelector('.underline-effect')) {
                bouton.querySelector('.underline-effect').style.transform = 'scaleX(0)';
            }
        });
    });
});






document.addEventListener('DOMContentLoaded', function() {
    const sliderContainer = document.querySelector('.slidermise');
    const slideContainer = document.querySelector('.slidermiseavant');
    const slides = document.querySelectorAll('.imgmise');
    const prevBtn = document.querySelector('.prev-btn'); // Assurez-vous que votre HTML a un élément avec cette classe
    const nextBtn = document.querySelector('.next-btn'); // Assurez-vous que votre HTML a un élément avec cette classe

    let currentIndex = 0;

    function updateSlide() {
        const slideWidth = sliderContainer.offsetWidth; // Utilisez la largeur du conteneur du slider
        slideContainer.style.transform = `translateX(${-currentIndex * slideWidth}px)`;
    }

    function nextSlide() {
        currentIndex = (currentIndex + 1) % slides.length;
        updateSlide();
    }

    function prevSlide() {
        currentIndex = (currentIndex - 1 + slides.length) % slides.length;
        updateSlide();
    }


    prevBtn.addEventListener('click', prevSlide);
    nextBtn.addEventListener('click', nextSlide);

    setInterval(nextSlide, 3000); // Corrige pour avancer toutes les 6 secondes
});