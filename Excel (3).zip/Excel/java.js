document.addEventListener('DOMContentLoaded', function() {  
    const boutons = document.querySelectorAll('.boutons a'); 
    boutons.forEach(function(bouton) {      
        bouton.addEventListener('mouseenter', function() {
            if (!bouton.querySelector('.underline-effect')) {
                const underline = document.createElement('span');
                underline.classList.add('underline-effect');
                underline.style.position = 'absolute';
                underline.style.bottom = '0';
                underline.style.left = '0';
                underline.style.width = '100%';
                underline.style.height = '2px';
                underline.style.backgroundColor = 'white';
                underline.style.transform = 'scaleX(0)';
                underline.style.transition = 'transform 0.3s ease';

                bouton.appendChild(underline);
            }
            requestAnimationFrame(function() {
                bouton.querySelector('.underline-effect').style.transform = 'scaleX(1)';
            });
        });
        bouton.addEventListener('mouseleave', function() {
            if (bouton.querySelector('.underline-effect')) {
                bouton.querySelector('.underline-effect').style.transform = 'scaleX(0)';
            }
        });
    });
});


document.addEventListener('DOMContentLoaded', (event) => {
    mettreAJourHoraire();
});

function mettreAJourHoraire() {
    const maintenant = new Date();
    const jour = maintenant.getDay();
    const heure = maintenant.getHours();
    const minutes = maintenant.getMinutes();
    const idJourActuel = joursDeLaSemaine[jour];

    // Heures d'ouverture sous forme de minutes depuis minuit
    const horairesOuverture = {
        "Lundi": { debut: 9 * 60, fin: 18 * 60 },
        "Mardi": { debut: 9 * 60, fin: 19 * 60 },
        "Mercredi": { debut: 9 * 60, fin: 19 * 60 },
        "Jeudi": { debut: 9 * 60, fin: 19 * 60 },
        "Vendredi": { debut: 9 * 60, fin: 19 * 60 },
        "Samedi": { debut: 9 * 60, fin: 19 * 60 },
        // Dimanche est fermé
    };

    // Convertissez l'heure actuelle en minutes depuis minuit
    const maintenantEnMinutes = heure * 60 + minutes;

    // Vérifiez si le magasin est actuellement ouvert
    if (idJourActuel in horairesOuverture) {
        const horaire = horairesOuverture[idJourActuel];
        if (maintenantEnMinutes >= horaire.debut && maintenantEnMinutes < horaire.fin) {
            document.getElementById(idJourActuel).classList.add("horaire-ouverte");
        }
    }
}

// Tableau pour convertir le numéro du jour en nom
const joursDeLaSemaine = {
    0: "Dimanche",
    1: "Lundi",
    2: "Mardi",
    3: "Mercredi",
    4: "Jeudi",
    5: "Vendredi",
    6: "Samedi"
};


