document.addEventListener('DOMContentLoaded', function() {  
    const boutons = document.querySelectorAll('.bouton3 a'); 
    boutons.forEach(function(bouton) {      
        bouton.addEventListener('mouseenter', function() {
            if (!bouton.querySelector('.underline-effect')) {
                const underline = document.createElement('span');
                underline.classList.add('underline-effect');
                underline.style.position = 'absolute';
                underline.style.bottom = '8px'; 
                underline.style.left = '0';
                underline.style.width = '100%';
                underline.style.height = '2px';
                underline.style.backgroundColor = 'black';
                underline.style.transform = 'scaleX(0)';
                underline.style.transition = 'transform 0.3s ease';

                bouton.appendChild(underline);
            }
            requestAnimationFrame(function() {
                bouton.querySelector('.underline-effect').style.transform = 'scaleX(1)';
            });
        });
        bouton.addEventListener('mouseleave', function() {
            if (bouton.querySelector('.underline-effect')) {
                bouton.querySelector('.underline-effect').style.transform = 'scaleX(0)';
            }
        });
    });
});